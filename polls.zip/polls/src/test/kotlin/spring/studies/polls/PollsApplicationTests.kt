package spring.studies.polls

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PollsApplicationTests {

	@Test
	fun contextLoads() {
	}

}
